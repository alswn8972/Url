<template>
  <status-list />
</template>

<script>
import statusList from "@/components/Status/statusList.vue";

export default {
  components: {
    statusList
  },
};
</script>