<template>
  <div class="content">
    <div class="md-layout">
      <div class="md-layout-item">
        <md-card class="md-card-plain">
          <md-card-header data-background-color="green">
            <h4 class="title">Material Design Icons</h4>
            <p class="category">
              Handcrafted by our friends from
              >
            </p>
          </md-card-header>

          <md-card-content>
            
          </md-card-content>
        </md-card>
      </div>
    </div>
  </div>
</template>

<script>
export default {};
</script>
