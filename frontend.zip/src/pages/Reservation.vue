<template>
  <reservation-form />
</template>

<script>
import reservationForm from "@/components/Reservation/reservationForm.vue";

export default {
  components: {
    reservationForm
  },
};
</script>