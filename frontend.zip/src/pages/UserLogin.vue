<template>
  <login-form />
</template>

<script>
import loginForm from "@/components/Login/loginForm";

export default {
  
  components: {
    loginForm
  },
};
</script>
