<template>
  <input-form/>
</template>

<script>
import inputForm from "@/components/Input/inputForm";

export default {
  components: {
    inputForm
  },
};
</script>