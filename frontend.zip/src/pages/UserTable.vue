<template>
  <table-list />
</template>

<script>
import tableList from "@/components/Table/tableList.vue";

export default {
  components: {
    tableList
  },
};
</script>