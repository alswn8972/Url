<template>
  <footer class="footer">
    <div class="container">
      <nav>
        <ul>
          <li>
            <a href="https://github.com/alswn8972">Minju Kang</a>
          </li>
        </ul>
      </nav>
    </div>
  </footer>
</template>
<script>
export default {};
</script>
<style></style>
