<template>
  <check-form />
</template>

<script>
import checkForm from "@/components/Check/checkForm";

export default {

  components: {
    checkForm
  },
};
</script>