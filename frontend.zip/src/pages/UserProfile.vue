<template>
  <join-form />
</template>

<script>
import joinForm from "@/components/Join/joinForm.vue";

export default {
  components: {
    joinForm
  },
};
</script>